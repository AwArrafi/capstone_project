package com.example.submission.ui

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.submission.R
import com.example.submission.api.ApiConfig
import com.example.submission.response.StoryDetailResponse

class DetailActivity : AppCompatActivity() {

    private lateinit var ivDetailPhoto: ImageView
    private lateinit var tvDetailName: TextView
    private lateinit var tvDetailDescription: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        // Inisialisasi Views
        ivDetailPhoto = findViewById(R.id.iv_detail_photo)
        tvDetailName = findViewById(R.id.tv_detail_name)
        tvDetailDescription = findViewById(R.id.tv_detail_description)

        // Ambil ID dari Intent
        val storyId = intent.getStringExtra("storyId") ?: return

        // Panggil API untuk mengambil detail story
        getStoryDetail(storyId)
    }

    private fun getStoryDetail(storyId: String) {
        val apiService = ApiConfig.getApiService()

        // API call untuk mengambil detail story
        apiService.getStoryDetail(storyId).enqueue(object : Callback<StoryDetailResponse> {
            override fun onResponse(call: Call<StoryDetailResponse>, response: Response<StoryDetailResponse>) {
                if (response.isSuccessful) {
                    val storyDetail = response.body()?.story
                    storyDetail?.let {
                        // Menampilkan data
                        tvDetailName.text = it.name
                        tvDetailDescription.text = it.description
                        Glide.with(this@DetailActivity)
                            .load(it.photoUrl)
                            .into(ivDetailPhoto)
                    }
                } else {
                    // Handle error
                    Toast.makeText(this@DetailActivity, "Failed to load story details", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<StoryDetailResponse>, t: Throwable) {
                // Handle failure
                Toast.makeText(this@DetailActivity, "Network error", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
